import random

def print_random_number():

    random_number = random.randrange(0, 101)
    

    print("*********")
    print(f"***{random_number}***")
    print("*********")


print_random_number()
print_random_number()
print_random_number()