def print_list(mat):
  for x in mat:
    print(x)

retter = ["pasta", "pizza", "tomatsuppe"]

print_list(retter)
