def volume(lengde, bredde, høyde):
    volumeregel = lengde * bredde * høyde
    return volumeregel

print("volumer blir:", volume(10, 30, 20))
print("volumer blir:", volume(2, 3, 5))
print("volumer blir:", volume(9, 6, 2))